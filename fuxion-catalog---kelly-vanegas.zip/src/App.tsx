/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, ShoppingCart, Check, Droplets, Stethoscope, Leaf, Plus } from 'lucide-react';
import { products, WA_BASE } from './data';
import { Category, Language, Product } from './types';

export default function App() {
  const [lang, setLang] = useState<Language>('es');
  const [activeCat, setActiveCat] = useState<Category>('all');

  const filteredProducts = useMemo(() => {
    if (activeCat === 'all') return products;
    return products.filter(p => p.cat === activeCat);
  }, [activeCat]);

  const t = (es: string, de: string) => (lang === 'es' ? es : de);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row overflow-x-hidden">
      {/* SIDEBAR */}
      <aside className="hero-pattern w-full lg:fixed lg:h-screen lg:w-[380px] p-10 lg:p-12 flex flex-col text-white border-r border-fuxion-green/20 overflow-y-auto z-50">
        <div className="font-extrabold text-fuxion-green text-[0.65rem] tracking-[0.3em] mb-12 uppercase opacity-80">
          FuXion® • Kelly Vanegas
        </div>
        
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-10"
        >
          <h1 className="text-5xl lg:text-6xl font-black text-white leading-[1.05] mb-8">
            {lang === 'es' ? (
              <>Nutrición <br /><span className="text-fuxion-green">que transforma</span></>
            ) : (
              <>Ernährung <br /><span className="text-fuxion-green">die verändert</span></>
            )}
          </h1>
          <p className="text-white/60 leading-relaxed text-sm max-w-[300px]">
            {t(
              'Descubre bebidas funcionales que combinan saberes ancestrales con ciencia de vanguardia.',
              'Entdecke funktionale Getränke, die jahrtausendealtes Wissen mit moderner Wissenschaft verbinden.'
            )}
          </p>
        </motion.div>

        {/* LANG TOGGLE */}
        <div className="flex gap-2 mb-12">
          <button
            onClick={() => setLang('es')}
            className={`px-6 py-2.5 rounded-full text-[0.65rem] font-black tracking-widest transition-all border ${
              lang === 'es' ? 'bg-fuxion-green border-fuxion-green text-fuxion-dark shadow-[0_0_15px_rgba(46,204,113,0.3)]' : 'border-white/20 text-white/50 hover:border-white/40'
            }`}
          >
            ESPAÑOL
          </button>
          <button
            onClick={() => setLang('de')}
            className={`px-6 py-2.5 rounded-full text-[0.65rem] font-black tracking-widest transition-all border ${
              lang === 'de' ? 'bg-fuxion-green border-fuxion-green text-fuxion-dark shadow-[0_0_15px_rgba(46,204,113,0.3)]' : 'border-white/20 text-white/50 hover:border-white/40'
            }`}
          >
            DEUTSCH
          </button>
        </div>

        <div className="mt-auto">
          {/* SIDEBAR CONTACT CARD */}
          <div className="contact-card-sidebar p-8 rounded-[32px]">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative">
                <div className="w-3 h-3 bg-fuxion-green rounded-full shadow-[0_0_10px_#2ecc71]" />
                <div className="absolute inset-0 w-3 h-3 bg-fuxion-green rounded-full animate-ping opacity-50" />
              </div>
              <span className="text-white text-xs font-black uppercase tracking-widest">{t('Asesoría Directa', 'Direkte Beratung')}</span>
            </div>
            <p className="text-white/60 text-[0.7rem] leading-relaxed mb-6">
              {t('Consultas personalizadas con Kelly Gebauer.', 'Persönliche Beratung mit Kelly Gebauer.')}
              <br />
              <span className="text-fuxion-green font-black mt-2 inline-block text-sm">+49 176 3065 2738</span>
            </p>
            <a
              href={WA_BASE + encodeURIComponent(t('Hola Kelly!', 'Hallo Kelly!'))}
              target="_blank"
              className="block bg-fuxion-green text-fuxion-dark text-center py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-lg"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 lg:ml-[380px] p-6 lg:p-14 bg-fuxion-light min-h-screen">
        <header className="flex flex-col md:flex-row justify-between items-center gap-6 mb-12">
          <div className="text-center md:text-left w-full md:w-auto">
            <div className="bg-fuxion-green-light text-fuxion-green-dark px-3 py-1 rounded-full text-[0.6rem] font-black inline-block mb-3 uppercase tracking-widest">
              {t('CATÁLOGO 2024', 'KATALOG 2024')}
            </div>
            <h2 className="text-3xl lg:text-4xl font-black text-fuxion-dark uppercase tracking-tight">
              {t('Líneas de Bienestar', 'Wellness-Linien')}
            </h2>
          </div>
          <div className="flex gap-12 bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
            <div className="text-center">
              <div className="text-4xl font-black text-fuxion-green-dark">20+</div>
              <div className="text-[0.6rem] text-gray-400 font-bold uppercase tracking-wider">{t('Países', 'Länder')}</div>
            </div>
            <div className="h-10 w-px bg-gray-100 self-center" />
            <div className="text-center">
              <div className="text-4xl font-black text-fuxion-green-dark">100%</div>
              <div className="text-[0.6rem] text-gray-400 font-bold uppercase tracking-wider">{t('Natural', 'Natürlich')}</div>
            </div>
          </div>
        </header>

        {/* TABS AS TAGS (MATCHING FOOTER IN THE DESIGN) */}
        <div className="flex flex-wrap gap-2 mb-10 overflow-x-auto pb-2 no-scrollbar">
          <TabButton id="all" label={t('Todos', 'Alle')} icon="✨" active={activeCat === 'all'} onClick={setActiveCat} />
          <TabButton id="base" label={t('Base Diaria', 'Basis')} active={activeCat === 'base'} onClick={setActiveCat} />
          <TabButton id="weight" label={t('Peso & Medidas', 'Gewicht')} active={activeCat === 'weight'} onClick={setActiveCat} />
          <TabButton id="sport" label={t('Sport', 'Sport')} active={activeCat === 'sport'} onClick={setActiveCat} />
          <TabButton id="beauty" label={t('Belleza', 'Schönheit')} active={activeCat === 'beauty'} onClick={setActiveCat} />
          <TabButton id="mind" label={t('Mente', 'Geist')} active={activeCat === 'mind'} onClick={setActiveCat} />
          <TabButton id="immune" label={t('Inmune', 'Abwehr')} active={activeCat === 'immune'} onClick={setActiveCat} />
        </div>

        {/* PRODUCT GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-16">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} lang={lang} />
            ))}
          </AnimatePresence>
        </div>

        {/* DESIGN FOOTER */}
        <footer className="grid lg:grid-cols-[1fr_auto] gap-8 items-center p-8 bg-white rounded-[24px] border border-dashed border-gray-300">
           <div className="flex gap-2 overflow-hidden flex-wrap">
              <span className="px-4 py-2 bg-gray-50 text-gray-400 rounded-xl text-[0.7rem] font-bold">🌿 {t('Peso & Medidas', 'Gewicht')}</span>
              <span className="px-4 py-2 bg-gray-50 text-gray-400 rounded-xl text-[0.7rem] font-bold">🧠 {t('Mente & Sueño', 'Geist')}</span>
              <span className="px-4 py-2 bg-gray-50 text-gray-400 rounded-xl text-[0.7rem] font-bold">🛡️ {t('Inmunológica', 'Abwehr')}</span>
           </div>
           <div className="text-right text-[0.7rem] text-gray-400 leading-relaxed">
             © 2024 Distribuidor Independiente: <strong className="text-fuxion-dark">Kelly Vanegas Gebauer</strong><br />
             {t('Bebidas Nutracéuticas de alta biodisponibilidad.', 'Nutrazeutische Getränke mit hoher Bioverfügbarkeit.')}
           </div>
        </footer>
      </main>
    </div>
  );
}

function TabButton({ id, label, active, onClick }: { id: Category; label: string; active: boolean; onClick: (id: Category) => void }) {
  return (
    <button
      onClick={() => onClick(id)}
      className={`px-4 py-2 rounded-xl text-[0.7rem] font-bold transition-all whitespace-nowrap ${
        active 
          ? 'bg-fuxion-green-dark text-white shadow-md' 
          : 'bg-white text-gray-500 border border-gray-100 hover:bg-gray-50'
      }`}
    >
      {label}
    </button>
  );
}

function ProductCard({ product, lang }: { product: Product; lang: Language }) {
  const [isOpen, setIsOpen] = useState(false);
  const t = (es: string, de: string) => (lang === 'es' ? es : de);

  return (
    <motion.div
      layout
      className="bg-white rounded-[24px] p-6 product-card-shadow flex flex-col overflow-hidden group border border-transparent hover:border-fuxion-green/30 transition-colors"
    >
      <div className={`h-[140px] bg-gradient-to-br ${product.bg} rounded-[20px] flex items-center justify-center text-7xl mb-5 shadow-sm`}>
        {product.emoji}
      </div>
      
      <div className="flex justify-between items-start mb-1">
        <h3 className="text-lg font-black text-fuxion-dark tracking-tight">{product.name}</h3>
        <div className="text-[0.6rem] font-black text-fuxion-green-dark bg-fuxion-green-light px-2 py-0.5 rounded-full uppercase">
          {product.badge}
        </div>
      </div>
      
      <div className="text-fuxion-green-dark text-[0.65rem] font-bold uppercase tracking-wide mb-3">
        {t(product.cat.toUpperCase(), product.cat.toUpperCase())}
      </div>

      <p className="text-gray-500 text-[0.8rem] leading-relaxed mb-6 flex-1">
        {t(product.tagline_es, product.tagline_de)}
      </p>

      <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="text-[0.65rem] font-bold text-fuxion-green-dark hover:underline"
        >
          {isOpen ? t('Cerrar', 'Schließen') : t('✅ Detalles', '✅ Details')}
        </button>
        <a 
          href={WA_BASE + encodeURIComponent(`${t('Info sobre', 'Info über')} ${product.name}`)}
          target="_blank"
          className="text-[0.65rem] font-black text-fuxion-dark uppercase tracking-widest hover:text-fuxion-green"
        >
          {t('Kaufen', 'Kaufen')}
        </a>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mt-4 pt-4 border-t border-gray-50"
          >
            <div className="text-[0.7rem] text-gray-500 space-y-3">
              <div>
                <strong className="text-fuxion-dark block mb-1">{t('Beneficios:', 'Vorteile:')}</strong>
                <ul className="list-disc pl-4">
                  {(lang === 'es' ? product.benefits_es : product.benefits_de).map((b, i) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>
              </div>
              <p className="italic text-fuxion-green-dark">
                {t(product.tip_es, product.tip_de)}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
