export type Category = 'all' | 'base' | 'weight' | 'sport' | 'beauty' | 'mind' | 'immune';
export type Language = 'es' | 'de';

export interface Product {
  id: string;
  cat: Category;
  bg: string;
  emoji: string;
  image?: string;
  badge: string;
  name: string;
  tagline_es: string;
  tagline_de: string;
  benefits_es: string[];
  benefits_de: string[];
  how_es: string;
  how_de: string;
  tip_es: string;
  tip_de: string;
  ingredients_es: string;
  ingredients_de: string;
}
